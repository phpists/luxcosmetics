<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\PropertyCategory;
use App\Services\ImageService;
use App\Services\SiteService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Nette\Utils\Image;

class CategoryController extends Controller
{
    public function index() {
        $categories = Category::query()->whereNull('category_id')->with('subcategories')->get();
        return view('admin.categories.index', compact('categories'));
    }
    public function show(Request $request, string $alias) {
        $query = Category::query();
        $query->where('alias', $alias);
        $category = $query->with('subcategories')->first();
        return response()->json($category);
    }

    public function create() {
        $categories = Category::query()->get();
        return view('admin.categories.create', compact('categories'));
    }

    public function store(Request $request) {
        $data = $request->all();
        $image = ImageService::saveImage('uploads', 'categories', $request->image);
        if ($image){
            $data['image'] = $image;
            $data['add_to_top_menu'] = array_key_exists('add_to_top_menu', $data)?1:0;
            $curr_position = DB::table('categories')->max('position')??0;
            $data['position'] = $curr_position + 1;
            $category = new Category($data);
            if (!$category->save()) {
                redirect()->back()->with('error', 'Не удалось сохранить категорию');
            }
            if ($data['category_id'] !== null) {
                $data = PropertyCategory::query()
                    ->select('category_id', 'property_id', 'position')
                    ->where('category_id', $data['category_id'])->get();

                $data = $data->map(function ($item, int $key) use ($category) {
                    $item['category_id'] = $category->id;
                    return $item;
                });

                PropertyCategory::query()->insert($data->toArray());
            }
        }
        else {
            redirect()->back()->with('error', 'Не удалось сохранить изображение');
        }
        return redirect()->route('admin.categories')->with('success', 'Категория создана');
    }

    public function delete($id) {
        $category = Category::query()->find($id);
        if ($category->delete()) {
            ImageService::removeImage('uploads', 'categories', $category->image);
            Category::query()->where('category_id', $category->id)->update([
                'category_id' => $category->category_id
            ]);
        }
        return redirect()->back()->with('succcess', 'Категория успешно удалена');
    }

    public function edit($id) {
        $categories = Category::query()->get();
        $category = $categories->find($id);
        $properties = PropertyCategory::query()->where('category_id', $category->id)->orderBy('position')->paginate();
        return view('admin.categories.edit', compact('category', 'categories', 'properties'));
    }

    public function update(Request $request){
        $data = $request->all();
        $category = Category::query()->find($data['id']);
        $data['add_to_top_menu'] = array_key_exists('add_to_top_menu', $data)? 1: 0;
        if(!$category) {
            return redirect()->back()->with('error', 'Категория не найдена');
        }
        if ($request->hasFile('image')) {
            $image = ImageService::saveImage('uploads', 'categories', $request->image);
            if ($image) {
                $data['image'] = $image;
            }
            else {
                return redirect()->back()->with('error', 'Не удалось сохранить изображение');
            }
        }
        $is_same_parent = false;
        if ($data['category_id'] !== null) {
            $is_same_parent = ((int)$data['category_id'] === (int)$category->category_id);
        }
        $category->update($data);
        if ($data['category_id'] !== null && !$is_same_parent) {
            $data = PropertyCategory::query()
                ->select('category_id', 'property_id', 'position')
                ->where('category_id', $data['category_id'])->get();

            PropertyCategory::query()->where('category_id', $category->id)->delete();

            $data = $data->map(function ($item, int $key) use ($category) {
                $item['category_id'] = $category->id;
                return $item;
            });

            PropertyCategory::query()->insert($data->toArray());
        }
        return redirect()->route('admin.categories')->with('success', 'Категория успешно отредактирована');
    }

    public function deleteCategories(Request $request)
    {
        $categoriesId = $request->checkbox;
        if ($categoriesId) {
            $categories = Category::query()->whereIn('id', $categoriesId)->get();
            foreach ($categories as $category) {
                if($category->image) {
                    ImageService::removeImage('uploads', 'categories', $category->image);
                }
                Category::query()->where('category_id', $category->id)->whereNotIn('id', $categoriesId)->update([
                    'category_id' => $category->category_id
                ]);
            }
        }

        return response()->json([
            'status' => true,
            'categories' => $categoriesId,
            'message' => 'Категории успешно удалены!'
        ]);
    }

    public function activeCategories(Request $request)
    {
        $categoriesId = $request->checkbox;
        $status = $request->status;
        if ($categoriesId) {
            Category::whereIn('id', $categoriesId)->update([
                'status' => $status
            ]);
        }

        $title = SiteService::getStatus($status);
        $message = $status ? 'Категории активированы!' : 'Категории деактивированы!';

        return response()->json([
            'categories' => $categoriesId,
            'title' => $title,
            'message' => $message
        ]);
    }

    public function updatePosition(Request $request) {
        foreach ($request->data as $pos => $new_position) {
            $parent_id = array_key_exists('parent_id', $new_position)?$new_position['parent_id']:null;
            $category = Category::query()->find($new_position['id']);
            $is_same_parent = false;
            if ($parent_id !== null) {
                $is_same_parent = ((int)$parent_id === (int)$category->category_id);
            }
            $category->update([
                'position' => $pos,
                'category_id' => $parent_id
            ]);
            if ($parent_id !== null && !$is_same_parent) {
                $data = PropertyCategory::query()
                    ->select('category_id', 'property_id', 'position')
                    ->where('category_id', $parent_id)->get();

                $data = $data->map(function ($item, int $key) use ($new_position) {
                    $item['category_id'] = $new_position['id'];
                    return $item;
                });

                PropertyCategory::query()->where('category_id', $new_position['id'])->delete();

                PropertyCategory::query()->insert($data->toArray());
            }
        }
        return response()->json(['status' => 'ok']);
    }

    public function updatePropertiesPosition(Request $request): \Illuminate\Http\JsonResponse
    {
        $positions = $request->post('positions');
        if ($positions) {
            foreach ($positions as $position) {
                $property_category = PropertyCategory::findOrFail($position['id']);
                $property_category->position = $position['pos'];
                $property_category->save();
            }
        }

        $property_category = PropertyCategory::pluck('position', 'id');
        return response()->json($property_category);
    }
}
