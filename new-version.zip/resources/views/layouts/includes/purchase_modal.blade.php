<div class="popupform" id="addproduct">
    <div class="popupform__title">Вы добавили в корзину</div>
    <div class="addprod">
        <div class="addprod__image"><img src="images/dist/tmp-product2.jpg" alt=""></div>
        <div class="addprod__wrap">
            <div class="addprod__title"><a href="">YVES SAINT LAURENT</a></div>
            <div class="addprod__subtitle">Libre Eau de Parfum (50ml)</div>
            <div class="addprod__options">
                <div class="addprod__option">Выбранный цвет: <b>Red</b></div>
                <div class="addprod__option">Выбранный размер: <b>90ml</b></div>
            </div>
            <div class="addprod__price">10 073 ₽ </div>
        </div>
    </div>
    <div class="popupform__btns">
        <button class="btn btn--border-main">Продолжить покупки</button>
        <a href="" class="btn btn--accent">Оформить заказ</a>
    </div>
</div>
