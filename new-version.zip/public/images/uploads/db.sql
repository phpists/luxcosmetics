INSERT INTO categories (name, alias, category_id, position, status, add_to_top_menu, created_at, updated_at, image)
VALUES
    ('Парфуми', 'perfumes', NULL, 1, 1, 1, NOW(), NOW(), NULL),
    ('Догляд за обличчям', 'face', NULL, 2, 1, 1, NOW(), NOW(), NULL),
    ('Догляд за волоссям', 'hair', NULL, 3, 1, 1, NOW(), NOW(), NULL),
    ('Засіб для чищення', 'skincare_cleanser', 2, 4, 1, 0, NOW(), NOW(), 'Balm.jpg'),
    ('Зволожуючі засоби', 'skincare_routines', 2, 5, 1, 0, NOW(), NOW(), 'Face cream-1.jpg'),
    ('Чоловічі парфуми', 'fragrance_men', 1, 6, 1, 0, NOW(), NOW(), 'MEN ΓÇô 1.jpg'),
    ('Миючі засоби', 'bath_body', NULL, 7, 1, 1, NOW(), NOW(), NULL),
    ('Догляд за тілом', 'bath_body_wellness', 7, 8, 1, 1, NOW(), NOW(), 'BODYCARE ΓÇô 2.jpg'),
    ('Жіночі парфуми', 'fragrance_women', 1, 6, 1, 0, NOW(), NOW(), 'WOMEN ΓÇô 1.jpg');
INSERT INTO brands (name)
VALUES
    ('YVES SAINT LAURENT'),
    ('ESTEE LAUDER'),
    ('KERASTASE'),
    ('DIOR'),
    ('LA MER'),
    ('BIODERMA'),
    ('GIORGIO ARMANI');
INSERT INTO products (title, alias, code, code_1c, status, price, discount_price, category_id, brand_id, description_1, description_2, description_3, availability, created_at, updated_at)
VALUES
    ('Libre Intense Eau de Parfum', 'libre-intense-eau-de-parfum', 'FLD001', 'FLD001C', 1, 1299.99, NULL, 1, 1,
     '<span style="font-weight: bold;">ABOUT THE FRAGRANCE:</span><div>LIBRE Eau de Parfum Intense is the new <a href="https://www.faces.com/ae-en/fragrance" style="font-weight: bold;">fragrance</a> by <a href="https://www.faces.com/ae-en/brandpage_ysl.html" style="font-weight: bold;">Yves Saint Laurent</a>, a more sensual take on the iconic<a href="https://www.faces.com/ae-en/sale_loreal_luxe_offer/libre-eau-de-parfum/034814801769.html" style="font-weight: bold;"> Eau de Parfum</a>. <br>The signature notes of lavender essence from France and Moroccan orange blossom combine with glowing orchid and warm vanilla to push the perfume to the extreme.</div><div>It is a long-lasting unique twist on the <a href="https://www.faces.com/ae-en/search?q=floral&amp;lang=en_AE" style="font-weight: bold;">floral fragrance</a>.</div><div><br></div><div><span style="font-weight: bold;">FRAGRANCE FAMILY:</span></div><div><a href="https://www.faces.com/ae-en/search?q=Floral&amp;lang=en_AE" style="font-weight: bold;">Floral</a><br><br></div><div><span style="font-weight: bold;">KEY NOTES:</span></div><div>Lavender Essence, Orange Blossom, Orchid and Warm Vanilla</div><div><br></div><div><span style="font-weight: bold;">ABOUT THE BOTTLE:</span></div><div>LIBRE means free. It is a celebration of freedom: a fragrance for those who do what they want and dare to be exactly who they are.<br>Drawing inspiration from the couture runways, the IT-bottle pushes its'' couture statement further with a <a href="https://www.faces.com/ae-en/search?q=masculine&amp;lang=en_AE" style="font-weight: bold;">masculine</a> camel color twisted in the most <a href="https://www.faces.com/ae-en/search?q=feminine&amp;lang=en_AE" style="font-weight: bold;">feminine</a> way, amplifying the intensity of the original bottle.<br></div>',
     'Spray the <a href="https://www.faces.com/ae-en/fragrance" style="font-weight: bold;">fragrance </a>on the pulse points i.e. your neck and wrists, they emanate heat that helps the fragrance project from your skin for a longer-lasting, stronger scent.', NULL, 1, NOW(), NOW()),
    ('Advanced Night Repair Synchronized Multi-Recovery Complex', 'advanced-night-repair-synchronized-multi-recovery-complex', 'TSH001', 'TSH001C', 1, 1290.99, 900.99, 2, 2,
     '<h3 class="acc-title font-weight-extra-bold f-mb-0 f-pr-6 f-py-8 f-pt-xl-20 f-pb-xl-12 d-none d-md-block">
    Product Details
    </h3>
    <div class="d-block">
    </div>
    <div class="section-sub-title f-mt-16 f-mb-4 d-none d-md-block font-weight-extra-bold">
    Description
    </div>
    <div class="long-description f-mb-md-8">
    <p><span style="font-weight: bold;">ABOUT THE PRODUCT:</span><br>A next-generation super <a href="https://www.faces.com/ae-en/search?q=serum&amp;lang=en_AE" style="font-weight: bold;">serum </a>that visibly reduces multiple signs of <a href="https://www.faces.com/ae-en/search?q=aging&amp;lang=en_AE" style="font-weight: bold;">aging</a> with fast-repair and youth-generating power.<br></p><p><br><span style="font-weight: bold;">SKIN TYPE</span>&nbsp;</p><p>Normal, Dry, Oily, and Combination</p><p><span style="font-weight: bold;">SKIN CONCERN&nbsp;</span></p><p>Fine Lines and Wrinkles, Dullness, and Loss of Firmness and Elasticity<br></p><p><span style="font-weight: bold;">FORMULATION</span>&nbsp;</p><p>Liquid</p><p><span style="font-weight: bold;">INGREDIENTS CALL-OUTS</span>&nbsp;</p><p>Free of phthalates, mineral oil, sulfates SLS &amp; SLES, and contains less than one percent synthetic fragrance.<br><br><span style="font-weight: bold;">KEY INGREDIENT &amp; EFFECT</span></p><p><a href="https://www.faces.com/ae-en/search?q=Hyaluronic+Acid&amp;lang=en_AE" style="font-weight: bold;">Hyaluronic Acid</a>: Locks in moisture for up to 72 hours.<br><br><span style="font-weight: bold;">WHAT IT DOES</span></p><p>Formulated with Chronolux™ Power Signal Technology, this fast-penetrating serum visibly minimizes multiple signs of aging by supporting the skin’s natural ability to repair and boost collagen. <br>Up to eight hours of antioxidant protection defend against environmental assaults while high levels of hyaluronic acid lock in moisture for up to 72 hours, helping to optimize the skin’s natural repair process. <br><br><span style="font-weight: bold;">WHAT ELSE YOU NEED TO KNOW</span></p><p>It is dermatologist-tested and ophthalmologist-tested. This serum is also Non-acnegenic; it won''t clog pores. It comes in a recyclable glass bottle.<br><br><span style="font-weight: bold;">RESULTS</span></p><p>Skin is left looking smoother, less lined, more even-toned, and more radiant, and plumped with hydration. <br>Over time, pores appear diminished.<br><br></p><div>In consumer testing on 543 women, after 3 weeks:</div><div>- 88% of women said skin looked more youthful</div><div>- 89% of women agreed skin felt firmer</div><div>- Skin looked healthy with a new visible bounce and vitality</div><p></p>
    </div>
    <a href="javascript:void(0)" class="long-description-link text-underline d-md-none js-description-learn-more js-tabs-reveal-btn">Learn More</a>',
     '<p>Apply this face serum on clean skin before your moisturizer, AM, and PM. Use one dropper. <br>Smooth in gently all over face and Neck.<br></p>', NULL, 1, NOW(), NOW()),
    ('Discipline Maskeratine Hair Mask', 'discipline-maskeratine-hair-mask', 'MTSH001', 'MTSH001C', 1, 120.99, 99.99, 3, 3,
     'Daily deep conditioning hair mask seals the ends to help prevent future blow dry heat damage, provides extreme softness and suppleness for fine to coarse, unruly hair.
Lighter and glossier than a butter, a creamy product that is nourishing, but light, with a bit more slip. This texture feels luxurious in the hands and lightly coats the hair—excellent for controlling frizz and smoothing flyaways.',
     'Apply Maskeratine Hair Mask to damp, cleansed hair on the mid-lengths and ends. Massage into the hair fiber. Leave in for 5 minutes then rinse thoroughly.',
     NULL, 1, NOW(), NOW()),
    ('Sauvage Eau de Parfum', 'sauvage-eau-de-parfum', 'PMD001', 'PMD001C', 1, 990.99, NULL, 1, 4,
     'The powerful freshness of Sauvage exudes new sensual and mysterious facets, amply renewing itself with the signature of an ingenious composition. Calabrian bergamot, as juicy and spirited as ever, invites new spicy notes to add fullness and sensuality, as the woody ambery trail of Ambroxan® is wrapped in the smoky accents of Papua New Guinean vanilla absolute for greater virility. François Demachy, Dior Perfumer-Creator, drew inspiration from the desert in the magical hour of twilight. Mixed with the coolness of the night, the burning desert air exudes profound fragrances. In the hour when the wolves come out and the sky is set ablaze, a new magic unfolds',
     'Spray the fragrance on the pulse points i.e. your neck and wrists, they emanate heat that helps the fragrance project from your skin for a longer-lasting, stronger scent.',
     NULL, 1, NOW(), NOW()),
    ('Capture Youth Glow Booster Age-Delay Illuminating Serum', 'capture-youth-glow-booster-age-delay-illuminating-serum', 'PMD001', 'PMD001C', 1, 990.99, NULL, 1, 4,
     'This illuminating serum is a glow booster to help restore radiance. Murunga plum, known to be 100 times more concentrated in vitamin C than oranges, combined with alpha hydroxy acid helps to brighten the complexion and smooth skin texture. Enriched with antioxidant-boosting iris extract, this serum has a lightweight texture that offers a natural glow and energizes skin, helping it resist aggressions (stress, fatigue, and jet lag).',
     NULL, NULL, 1, NOW(), NOW()),
    ('The Moisturizing Cool Gel Cream', 'the-moisturizing-cool-gel-cream', 'PfdfMD001', 'PMfdfdD001C', 1, 990.99, NULL, 5, 5,
     'This cooling gel delivers soothing moisture for a refreshed feel. Skin looks naturally vibrant, restored to its healthiest looking center. Miracle Broth™ – the legendary healing elixir that flows through all of La Mer – infuses skin with sea-sourced renewing energies. Ideal for combination / oilier skin.',
     NULL, NULL, 1, NOW(), NOW()),
    ('Sebium Gel Moussant Purifying Foaming Cleanser for Combination/oily Skin', 'sebium_gel_purif','PfdffdMD001', 'PMfdfdffdD001C', 1, 990.99, NULL, 5, 5,
     'Gently cleanses and purifies Limits sebum secretion Keeps pores from becoming clogged Guarantees good skin and eye tolerance Scented formula - Non-comedogenic - Non-drying - Soap-free',
     'Morning and/or evening – 7 days a week STEP 1 Apply on wet skin. STEP 2 Work into a foam. STEP 3 Rinse well. STEP 4 Gently dry. STEP 5 Can be used as a shaving foam.', NULL, 1, NOW(), NOW()),
    ('Sauvage Eau de Parfum', 'sauvage-eau-de-parfum__1','PdffdMD001fd', 'PMfdffdD00fd1C',
     1, 990.99, NULL, 6, 4,
     'The powerful freshness of Sauvage exudes new sensual and mysterious facets, amply renewing itself with the signature of an ingenious composition. Calabrian bergamot, as juicy and spirited as ever, invites new spicy notes to add fullness and sensuality, as the woody ambery trail of Ambroxan® is wrapped in the smoky accents of Papua New Guinean vanilla absolute for greater virility. François Demachy, Dior Perfumer-Creator, drew inspiration from the desert in the magical hour of twilight. Mixed with the coolness of the night, the burning desert air exudes profound fragrances. In the hour when the wolves come out and the sky is set ablaze, a new magic unfolds.',
     'Spray the fragrance on the pulse points i.e. your neck and wrists, they emanate heat that helps the fragrance project from your skin for a longer-lasting, stronger scent.',
     NULL, 1, NOW(), NOW()),
    ('Sauvage Eau de Parfum v2', 'sauvage-eau-de-parfum_v2','UPdffdMD001fd', 'UPMfdffdD00fd1C',
     1, 990.99, NULL, 6, 4,
     'The powerful freshness of Sauvage exudes new sensual and mysterious facets, amply renewing itself with the signature of an ingenious composition. Calabrian bergamot, as juicy and spirited as ever, invites new spicy notes to add fullness and sensuality, as the woody ambery trail of Ambroxan® is wrapped in the smoky accents of Papua New Guinean vanilla absolute for greater virility. François Demachy, Dior Perfumer-Creator, drew inspiration from the desert in the magical hour of twilight. Mixed with the coolness of the night, the burning desert air exudes profound fragrances. In the hour when the wolves come out and the sky is set ablaze, a new magic unfolds.',
     'Spray the fragrance on the pulse points i.e. your neck and wrists, they emanate heat that helps the fragrance project from your skin for a longer-lasting, stronger scent.',
     NULL, 1, NOW(), NOW());
INSERT INTO product_variations (product_id, size, price, discount_price)
VALUES
    (1, '50ml', 1500.99, NULL),
    (1, '100ml', 2000.99, 1800.99),
    (2, '50ml', 1000, NULL),
    (2, '250ml', 1600, 1400),
    (4, '50ml', 1000, NULL),
    (4, '250ml', 1600, 1400),
    (6, '150ml', 1200, 1000),
    (6, '250ml', 1600, 1400),
    (8, '150ml', 1200, 1000),
    (8, '250ml', 1200, 1000);
INSERT INTO images (record_id, path)
values ('1', '887167485471.jpg'),
       ('1', '887167485501_2.jpg'),
       ('1', '887167485501_3.jpg'),
       ('2', '3614273069540_.jpg'),
       ('2', '3614273069540_1.jpg'),
       ('3', '3474636400218.jpg'),
       ('3', '3474636400218_1.jpg'),
       ('4', '3348901428545_.jpg'),
       ('4', '3348901428545.jpg'),
       ('5', '3348901465595_.jpg'),
       ('6', 'la_mer_moist.jpeg'),
       ('7', 'sebium.jpg'),
       ('7', 'sebium_1.jpg'),
       ('8', 'dior_test.jpg'),
       ('9', 'dior_test.jpg');
Update products set image_print_id = 1 where id = 1;
Update products set image_print_id = 3 where id = 2;
Update products set image_print_id = 6 where id = 3;
Update products set image_print_id = 8 where id = 4;
Update products set image_print_id = 10 where id = 5;
Update products set image_print_id = 11 where id = 6;
Update products set image_print_id = 12 where id = 7;
Update products set image_print_id = 14 where id = 8;
Update products set image_print_id = 15 where id = 9;

