{{ $categories->appends(request()->all())->links('vendor.pagination.category_pagination') }}
