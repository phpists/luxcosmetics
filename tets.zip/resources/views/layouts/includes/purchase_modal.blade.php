<div class="popupform mfp-hide" id="addproduct">
    <div class="popupform__title">Вы добавили в корзину</div>
    <div class="addprod">
{{--        <div class="numbers addprod__numbers">--}}
{{--            <div class="numbers__minus minus"><svg class="icon"><use xlink:href="{{asset('images/dist/sprite.svg#minus')}}"></use></svg></div>--}}
{{--            <input type="text" class="numbers__input" value="1">--}}
{{--            <div class="numbers__plus plus"><svg class="icon"><use xlink:href="{{asset('images/dist/sprite.svg#plus')}}"></use></svg></div>--}}
{{--        </div>--}}
    </div>
    <div class="popupform__btns">
        <button class="btn btn--border-main close">Продолжить покупки</button>
        <a href="{{ route('cart') }}" class="btn btn--accent">Оформить заказ</a>
    </div>
</div>
