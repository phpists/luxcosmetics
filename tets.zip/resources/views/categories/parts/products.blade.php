@foreach($products as $product)
    <div class="category-page__product">

        @include('products._card')

    </div>
@endforeach
