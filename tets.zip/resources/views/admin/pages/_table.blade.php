
{{ $pages->links('vendor.pagination.super_admin_pagination') }}
