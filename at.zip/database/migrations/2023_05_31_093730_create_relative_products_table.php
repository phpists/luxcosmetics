<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('relative_products', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('product_id')->comment('Товар');
            $table->bigInteger('product_related_id')->comment('Связанный товар');
            $table->smallInteger('relation_type');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('relative_products');
    }
};
